package com;

import java.util.Scanner;

public class CalculatingMarks {

	public static void main(String[] args) {
		
		System.out.println("Student marks");
		Scanner marks = new Scanner(System.in);

		System.out.println("Enter the maths marks");
		float maths = marks.nextInt();
		System.out.println("Enter the science marks");
		float science = marks.nextInt();
		System.out.println("Enter the EVS marks");
		float EVS = marks.nextInt();
		System.out.println("Enter the Hindi marks");
		float Hindi = marks.nextInt();
		System.out.println("Enter the English marks");
		float English = marks.nextInt();
		
		float sum = maths + science + EVS + Hindi + English ;
		float gpa=sum / 50;
		System.out.println(gpa);
//		double per =avg*100;
		System.out.println("Percentage is " +gpa+"%");
		if (gpa<=3.6) {
			
			System.out.println("He is fail");
		}
			else {
				System.out.println("he is pass");
			}
		}
		
	}



