package com;

import java.util.Scanner;

public class Rename {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 
		 System.out.println("Taking input from the user!!");
		 Scanner sc = new Scanner(System.in);
//		 System.out.println("ENter number A");
//		 int a= sc.nextInt();
////		 
//		 System.out.println("ENter number B");
//		 int b = sc.nextInt();
//		 int sum =a+b;
//		 System.out.println(sum);
//		 
//		 
////		 output will be get in boolean values
//		 boolean b1 = sc.hasNextInt();
//		 System.out.println(b1);
		 
//		 if we want to print total String line 
//		 String Str = sc.next();
		 String Str1 = sc.nextLine();
//		 System.out.println(Str);
		 System.out.println(Str1);
		 
		 
	 }

}
