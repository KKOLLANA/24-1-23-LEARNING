package com;

public class Sum {
	
public static void main(String args[]) {
	int a =10;
	int b= 20;
	int c = 30;
	int sum = a+b+c;
	System.out.println(sum);

}
}
